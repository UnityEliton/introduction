﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using MySql.Data.MySqlClient;

public class ConnectMySQL : MonoBehaviour
{
	public string host;
    public string database;
    public string username;
    public string password;

    private DBConnect mysql;
    // Use this for initialization
    void Start ()
    {
        mysql = new DBConnect(host, database, username, password);

        if (mysql.OpenConnection())
        {
            Debug.Log("Conectado");

            select(mysql);

            if (mysql.CloseConnection())
            {
                Debug.Log("Desconectado");
            }
        }
    }

    void select(DBConnect mysql){
    	MySqlCommand cmd = new MySqlCommand("SELECT * FROM user");

            cmd.Connection = mysql.connection;

            MySqlDataReader reader = cmd.ExecuteReader();
            string nameStr;
            string emailStr;
            while (reader.Read())
            {
                nameStr = reader["nome"].ToString();
                nameStr += " " + reader["email"].ToString();
                Debug.Log(nameStr);

            }
    }
}
